#!/usr/bin/perl
# Tina Boegel, 2025
# A pipeline wrapping the generation of Gothic 2P clitics/question particle =u
# at the syntax-prosody interface (implementing prosodic inversion in production)

# ###############################################################
# ===============================================================
print "\n>> Step 1: Generating the syntactic string \n";
print "======================================================\n";
print "This section starts XLE and uses an xlerc file to generate
the syntactic string starting from a prolog f-structure.
The string is saved in s-string.txt, c-structure as bracketed 
representation in cs.txt, and the string is parsed for inspection. 
Press `enter', then type `exit' to leave XLE and continue.\n\n";

$input = <STDIN>;

$XLE = 'xle -f grammar/xlerc';
system($XLE) == 0 or die "die";

# ###############################################################
# ===============================================================
print "\n>> Step 2:  The transfer of vocabulary\n";
print "======================================================\n";
print "This part tokenizes the s-string and matches the s-forms against
an xfst lexicon. The p-form information becomes available and is 
transferred to p-structure (press 'enter' to continue).\n";
$input = <STDIN>;

print "a) Tokenizing the generated string\n\n";
# This opens the file containing the s-string (horizontal) and transforms it into the format of 
# an xfst wordlist (vertical)

open(FILE, "grammar/s-string.txt");
open (WORDLIST, "> lexicon/wordlist.txt"); 


while (defined(my $t = <FILE>)) {
	chomp($t);
	foreach $line ($t){
		@words = split(/ /, $line);
	}
	foreach $word (@words){
		# turn all words into lower-case
		$word = lc($word);
		print WORDLIST "$word\n";
	}
}

close(FILE);
close(WORDLIST);

print "b) The s-string is matched against an xfst lexicon; p-forms become available\n\n";

# xfst is started, and the wordlist is matched against a lexicon, where the s-form
# is on the upper side, and the p-form on the lower side. A new wordlist is created that
# now contains the upper and the lower side information

$Path = '/Applications/fst64/bin/xfst';
$Script= 'lexicon/goth_script.xfst';

system("$Path -f $Script");

# The hash with all the lexical information in linear order
%pdiagram = {};
# The hash that stores the sforms as keys and their syllable number as values
%sforms = {};
$count = 0;

# The p-forms are stored as arrays in a hash that has numbers as keys to indicate linear order
open(FILELEX, "lexicon/p-forms.txt");
while (defined(my $t = <FILELEX>)) {
	chomp($t);
	foreach $line ($t){
		if (($line !~ /\+/) && ($line =~ /[a-z]/)){
			chomp($line);
			$sform = $line;
			#print "=> $sform\n";
		}
		elsif ($line =~ /\+/){
			$count += 1;
			@lex = split(/\+/, $line);
			push(@lex, $sform);
			$pdiagram{$count}=[@lex];
			#print "$key\t$pdiagram{$count}[0]\t$pdiagram{$count}[1]\t$pdiagram{$count}[2]\t$pdiagram{$count}[3]\t$pdiagram{$count}[4]\n";
			$sforms{$sform}= $lex[-2];
		}
	}
}
# keys: linear position in numbers
# values: arrays with: 1: form, 2: pw/cl, 3: number syll, 4: sform
# push (@{$pdiagram{$stresspos}}, $stress);  == pushing single values in the p-diagram's array

#foreach $key (sort { $a <=> $b} keys %sforms) {
#	print "$key >>  $sforms{$key}\n";
#}

close(FILELEX);

print "\nc) Based on the p-form information, the lexical part of the p-diagram is generated\n";

# This sorts through the hash and creates an array of syllables (segments), with matching 
# phrasing information based on cl or pw status, and includes a V-index for each successive
# element. The syllable numbers are determined based on the p-form, because the syll information 
# was added later.

@index = ();
@segments = ();
@phrasing = ();
$index = 0;

foreach $key (sort { $a <=> $b} keys %pdiagram) {
	@sylls = split(/\./, $pdiagram{$key}[0]);
	$length = @sylls;
	# If this has the status of a prosodic word
	if ($pdiagram{$key}[1] eq "pw"){
		# if this is one syllable long
		if ($length == 1){
			$index += 1;
			$Vindex = "V".$index;
			#print $Vindex;
			push(@index, $Vindex);
			push(@segments, $pdiagram{$key}[0]);
			push(@phrasing, "(σ)")
		}
		# if it is longer than one syllable, open boundary at first position, 
		# then determine the length so you know when to set a closing boundary
		elsif ($length > 1){
			$count_syll = 1;
			foreach $syllable (@sylls){
				if ($count_syll == 1){
					push(@phrasing, "(σ");
				}
				elsif ($count_syll == $length){
					push(@phrasing, "σ)");
				}
				else{push(@phrasing, "σ");
				}
				push(@segments, $syllable);
				$index += 1;
				$Vindex = "V".$index;
				push(@index, $Vindex);
				$count_syll += 1;
			}			
		}
	}	
	# If this has the status of a clitic, the just add that element
	elsif ($pdiagram{$key}[1] =~ /cl/){
		$index += 1;
		$Vindex = "V".$index;
		push(@index, $Vindex);
		push(@segments, $pdiagram{$key}[0]);
		push(@phrasing, $pdiagram{$key}[1]);
	}	
	#print "$key\t$pdiagram{$key}[0]\t$pdiagram{$key}[1]\t$pdiagram{$key}[2]\n";	
}


# ###############################################################
# ===============================================================
print "\n>> Step 3:  The transfer of structure:\n";
print "======================================================\n";
print "This part takes the bracketed c-structure (cs.txt), identifies the 
CP, and transfers this information to the p-diagram.
Further matching of other XPs is not pursued for now, but will be added later.
(Press 'enter' to continue)\n";
$input = <STDIN>;

# This part takes the nested c-structure in grammar cs.txt
# It isolates the CPs and assigns an IntP-boundary 
# It then counts left an right boundaries, matching them against each other 
# This could be extended much more, but it's just a toy-grammar
open(FILECS, "grammar/cs.txt");

$count_bracket = 0;
$count_ibracket = -1;

@IntPhrasing = ();
while (defined(my $t = <FILECS>)) {
	chomp($t);
	foreach $line ($t){
		if ($line =~ /\(CP/){
			$IntP = "yes";
			$bracket = "open";
		}
		# if a bracket closes there is usually a lexical item
		elsif ($line =~  /\)/){
			@lexitem = split(/\:/, $line);
			@lexitem2= split(/ /, $lexitem[1]);
			$lexword = $lexitem2[1];
			# If this is the first lexical item after the intonational phrase boundary
			# insert an intonational phrase boundary
			$syllnr = $sforms{$lexword};
			if ($IntP eq "yes"){
				push(@IntPhrasing, "i(");
				$IntP = "no";
				$syllnr -= 1;
			}
			# This one counts the syllables and adds them to the array
			else{
				$count_sylls = 0;
				while ($count_sylls < $syllnr) {
					push(@IntPhrasing, "na");
					$count_sylls += 1;
				}
			}
		}
		# this section keeps track of opening and closing brackets so one knows where
		# the intonational phrase boundary has to close
		if ($line =~ /\(/){
			$count_bracket += 1;
			if ($bracket eq "open"){
				$count_ibracket = $count_bracket;
				$bracket = "close";
			}
		}
		if ($line =~ /\)/){
			$count_bracket -= 1;
			#print "-- $count_bracket\n";
		}
		# This is for the last collection of brackets
		if ($line =~ /\)\)\)/){
			@brackets = split(/[1-9]/, $line);
			@brackets2 = split(//, $brackets[2]);
			shift(@brackets2); #one already calcualted in previous if-clause
			$length_b = @brackets2;
			foreach $brack (@brackets2){
				$count_bracket -= 1;
				if ($count_bracket == $count_ibracket){
					pop(@IntPhrasing);
					push(@IntPhrasing, ")i");
				}
			}
		}
	}
}

close(FILECS);

# The IntPhrasing from the transfer of structure has to be added to the phrasing
$count_phrase = -1;
foreach $bound (@IntPhrasing){
	$count_phrase += 1;
	if ($bound =~ /i/){
		$phrase_item = $phrasing[$count_phrase];
		if ($bound =~ /\(/){
			$phrase_item = $bound . $phrase_item;
		} 
		elsif ($bound =~ /\)/){
			$phrase_item = $phrase_item . $bound;
		} 
		splice(@phrasing, $count_phrase, 1, $phrase_item);	
	}
}

# ###############################################################
# ===============================================================
print "\n++ Input to p-structure from transfers of vocabulary and structure:\n";
print "====================================================================\n";

print "Phrasing\t";
foreach $el (@phrasing){	
	print "$el\t";
}
print "\n";

print "Segments\t";
foreach $syll (@segments){	
	print "$syll\t";
}
print "\n";

print "V-index \t";
foreach $v (@index){	
	print "$v\t";
}
print "\n";

#$input = <STDIN>;

# ###############################################################
# ===============================================================
print "\n>> Step 4: Internal rules (e.g., prosodic inversion) and constraints apply:\n";
print "====================================================================\n";
print "In this part, the algorithm identifies a structure where an opening IntP 
is followed by an enclitic. Prosodic inversion is applied and the p-diagram is 
adjusted accordingly (Press 'enter' to continue)\n";
$input = <STDIN>;

# This looks for a left intonational phrase boundary followed by an enclitic (= pros. inv)
# Further rules and constraints should go in here

$count_items = -1;

foreach $item (@phrasing){
	$count_items += 1;
		#print "> $item: $count_items\n";
	if ($item =~ /i\(=cl/){
		$IntP_item = $count_items;
		$clitic = "=cl";
		$i_bound = "i(";
		$next_right = "no";
		$IntP_item_next = $count_items + 1;
	}
	# add the adjusted left element to phrasing
	elsif ($count_items == $IntP_item_next){
		$left_edge = $i_bound . $item;
		push(@phrasing_out, $left_edge);	
	}
	# Find the next right bracket, add =cl after that
	if (($item =~ /\)/) && ($next_right eq "no")){
		$landing = $count_items;
		$next_right = "yes";
		push(@phrasing_out, $item);
		push(@phrasing_out, $clitic);
	}
	# if none of the above, just add the to phrasing array
	elsif (($count_items != $IntP_item) && ($count_items != $IntP_item_next)) {
		push(@phrasing_out, $item);
	}	
}

# Once all points of interest (clitic, landing place) have been identified, the p-diagram 
# is being resorted.



$cl_lex = $segments[$IntP_item];
$count_seg = -1;
foreach $syll (@segments){
	$count_seg += 1;
	if (($count_seg != $IntP_item)) {
		push(@segments_out, $syll);
	}
	if ($count_seg == $landing){
		push(@segments_out, $cl_lex);
	}
		
}

# ###############################################################
# ===============================================================
print "\n++ Output of p-structure:\n";
print "====================================================================\n";


print "Phrasing\t";
foreach $el (@phrasing_out){	
	print "$el\t";
}
print "\n";

print "Segments\t";
foreach $syll (@segments_out){	
	print "$syll\t";
}
print "\n";

print "V-index \t";
foreach $v (@index){	
	print "$v\t";
}
print "\n";

