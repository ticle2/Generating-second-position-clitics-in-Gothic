% -*- coding: iso-8859-1 -*-

fstructure('u maguts driggkan stikl',
	% Properties:
	[
	'markup_free_sentence'('u maguts driggkan stikl'),
	'xle_version'('XLE release of Mar 17, 2017 21:12.'),
	'grammar'('/Users/ticle2/Desktop/Gothic_2P/Gothic_2P_implementation/grammar/gothic.lfg'),
	'grammar_date'('Aug 14, 2025 15:03'),
	'word_count'('4'),
	'statistics'('1 solutions, 0.005 CPU seconds, 0.093MB max mem, 13 subtrees unified'),
	'rootcategory'('CP'),
	'hostname'('MacBook-Pro-138.local')
	],
	% Choices:
	[
	
	],
	% Equivalences:
	[
	
	],
	% Constraints:
	[
	cf(1,eq(attr(var(0),'PRED'),semform('can',0,[var(2)],[var(1)]))),
	cf(1,eq(attr(var(0),'SUBJ'),var(1))),
	cf(1,eq(attr(var(0),'XCOMP'),var(2))),
	cf(1,eq(attr(var(0),'CLAUSE-TYPE'),'interrogative')),
	cf(1,eq(attr(var(0),'TENSE'),'pres')),
	cf(1,eq(attr(var(0),'VTYPE'),'modal')),
	cf(1,eq(attr(var(1),'PRED'),semform('PRO',1,[],[]))),
	cf(1,eq(attr(var(1),'NUM'),'dual')),
	cf(1,eq(attr(var(1),'PERS'),'2')),
	cf(1,eq(attr(var(2),'PRED'),semform('drink',2,[var(1),var(3)],[]))),
	cf(1,eq(attr(var(2),'SUBJ'),var(1))),
	cf(1,eq(attr(var(2),'OBJ'),var(3))),
	cf(1,eq(attr(var(2),'INF'),'+')),
	cf(1,eq(attr(var(2),'VTYPE'),'main')),
	cf(1,eq(attr(var(3),'PRED'),semform('cup',3,[],[]))),
	cf(1,eq(attr(var(3),'CASE'),'acc')),
	cf(1,eq(attr(var(3),'NUM'),'sg')),
	cf(1,eq(attr(var(3),'PERS'),'3'))
	],
	% C-Structure:
	[
	cf(1,subtree(25,'CP',10,24)),
	cf(1,phi(25,var(0))),
	cf(1,subtree(24,'C\'',12,23)),
	cf(1,phi(24,var(0))),
	cf(1,subtree(23,'IP',-,22)),
	cf(1,phi(23,var(0))),
	cf(1,subtree(22,'I\'',-,21)),
	cf(1,phi(22,var(0))),
	cf(1,subtree(21,'VP',18,20)),
	cf(1,phi(21,var(2))),
	cf(1,subtree(20,'NP',-,8)),
	cf(1,phi(20,var(3))),
	cf(1,subtree(18,'VP',-,6)),
	cf(1,phi(18,var(2))),
	cf(1,subtree(12,'C\'',-,4)),
	cf(1,phi(12,var(0))),
	cf(1,subtree(10,'CP',-,2)),
	cf(1,phi(10,var(0))),
	cf(1,subtree(8,'N',-,7)),
	cf(1,phi(8,var(3))),
	cf(1,terminal(7,'stikl',[7])),
	cf(1,phi(7,var(3))),
	cf(1,subtree(6,'V',-,5)),
	cf(1,phi(6,var(2))),
	cf(1,terminal(5,'driggkan',[5])),
	cf(1,phi(5,var(2))),
	cf(1,subtree(4,'Vaux',-,3)),
	cf(1,phi(4,var(0))),
	cf(1,terminal(3,'maguts',[3])),
	cf(1,phi(3,var(1))),
	cf(1,subtree(2,'CL',-,1)),
	cf(1,phi(2,var(0))),
	cf(1,terminal(1,'u',[1])),
	cf(1,phi(1,var(0))),
	cf(1,semform_data(0,4,3,3)),
	cf(1,semform_data(1,4,3,3)),
	cf(1,semform_data(2,6,10,10)),
	cf(1,semform_data(3,8,19,19)),
	cf(1,fspan(var(3),19,24)),
	cf(1,fspan(var(2),10,24)),
	cf(1,fspan(var(0),1,24)),
	cf(1,surfaceform(1,'u',1,2)),
	cf(1,surfaceform(3,'maguts',3,9)),
	cf(1,surfaceform(5,'driggkan',10,18)),
	cf(1,surfaceform(7,'stikl',19,24))
	]).
